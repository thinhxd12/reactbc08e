import React, { Component } from 'react'

export default class FooterComponent extends Component {
    render() {
        return (
            <div className="footer py-3 text-center">
                Footer Component
            </div>
        )
    }
}
