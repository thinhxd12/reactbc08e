import React, { Component } from 'react'

export default class ContentComponent extends Component {
    render() {
        return (
            <div className="content text-center py-5">
                Content Component
            </div>
        )
    }
}
