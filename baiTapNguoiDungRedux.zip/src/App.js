// import FunctionComponent from "./Components/FunctionComponent";
// import ClassComponent from "./Components/ClassComponent";
// import HomeComponent from "./Components/BaiTapLayoutComponent/HomeComponent";
// import Databinding from "./Databinding/Databinding";
// import BaiTapThucHanhLayout from "./BaiTapLayoutComponent/BaiTapThucHanhLayout/BaiTapThucHanhLayout";
// import Demo from "./Databinding/Demo";
// import HandleEvent from "./HandleEvent/HandleEvent";
// import StyleComponent from "./StyleComponent/StyleComponent";
// import HomeLayout from "./Props/DemoProps/HomeLayout";
// import StateDemo from "./StateDemo/StateDemo";
// import RenderWithMap from "./RenderWithMap/RenderWithMap";
// import ShoesShop from "./Props/ShoesShop/ShoesShop";
// import BaiTapXemChiTiet from "./Props/BaiTapXemChiTiet/BaiTapXemChiTiet";
// import ExerciseCarStore from "./Props/ExerciseCarStore/ExerciseCarStore";
// import ExerciseCart from "./Props/ExerciseCart/ExerciseCart";
// import BaiTapGioHang from "./DemoRedux/BaiTapGioHang/BaiTapGioHang";
// import BaiTapGameXucXac from "./DemoRedux/BaiTapGameXucXac/BaiTapGameXucXac";
import BaiTapQuanLyNguoiDung from "./DemoRedux/BaiTapQuanLyNguoiDung/BaiTapQuanLyNguoiDung";



function App() {
  return (
    <div className="App">
      {/* <HomeComponent/> */}
      {/* <Databinding/> */}
      {/* <BaiTapThucHanhLayout/> */}
      {/* <Demo/> */}
      {/* <HandleEvent/> */}
      {/* <StyleComponent/> */}
      {/* <StateDemo/> */}
      {/* <HomeLayout/> */}
      {/* <RenderWithMap/> */}
      {/* <ShoesShop/> */}
      {/* <BaiTapXemChiTiet /> */}
      {/* <ExerciseCarStore/> */}
      {/* <ExerciseCart/> */}
      {/* <BaiTapGioHang/> */}
      {/* <BaiTapGameXucXac/> */}
      <BaiTapQuanLyNguoiDung/>
    </div>
  );
}

export default App;
