import React, { Component } from 'react'
import SanPham from './SanPham'

export default class DanhSachSanPham extends Component {

    renderSanPham = () => {
        return this.props.mangSanPham.map((sanPham, index) => {
            return <div key={index} className="col-4">
                <SanPham sanPham={sanPham}/>
            </div>
        })
    }


    render() {
        return (
            <div className="row">
                {this.renderSanPham()}
            </div>
        )
    }
}
